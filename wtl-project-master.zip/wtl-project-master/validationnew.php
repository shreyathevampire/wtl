<?php

  // get values from html file

	$user = $_POST['username'];
	$pass = $_POST['password'];

	// to prevent mysql injection

	$user = stripcslashes($user);
	$pass = stripcslashes($pass);

	// connect to server and selevct database
	$con = mysqli_connect("localhost","root","","registrationform");
//	mysql_select_db("registrationform");

	// query the database for user

	$result = mysqli_query($con,"SELECT * FROM form WHERE username = '$user' and password = '$pass'") or die("failed to query database ".mysqli_error());
	$row = mysqli_fetch_array($result,MYSQLI_NUM);
	//$rowcount = mysqli_num_rows($result);
	//printf ("%d \n",$row);
	//printf ("%s %s \n",$row[4],$row[5]);
	//$user1 = $row[4];
	//$pass1 = $row[5];
	if ($row[4] == $user && $row[5] == $pass ) {
				//echo "<script type='text/javascript'>alert('login successful')</script>"; 
				//header("Location : http://localhost/wtl-project-master/home1.php");
				//exit;
		//echo '<div style="text-align:center;padding-top:200px;">Go New Page</div>'; 
		$gourl='http://localhost/wtl-project-master/home1.php';
		echo '<META HTTP-EQUIV="Refresh" Content="2; URL='.$gourl.'">';    
		exit;
	} else {
				echo "<script type='text/javascript'>alert('failed!')</script>";
	}
	

?>