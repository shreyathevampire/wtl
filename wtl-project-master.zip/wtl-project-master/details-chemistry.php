<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/home/user/Desktop/project/home.css" type="text\css">
    </head>
<body>

<div class="modal fade details-1" id="details-1" tableindex="-1" role="dialog" aria-labelledby="details-1" aria-hidden="true">
<div class ="modal-dialog modal-lg">
<div class="modal-content">
<div class="modal-header">
 <button class="close" type="button" data-dismiss="modal" aria-label="close">
     <span aria-hidden="true">&times;</span>
    </button> 
<h4 class="modal-title text-center">applied chemistry</h4>
    
    </div>
<div class="modal-body">
    <div class="container-fluid">
    <div class="row">
        <div class="col-sm-6">
        <div class="center-block">
        <img src="chemistry.png" alt="chemistry" class="details img-responsive"/>
            
            </div>
        
        </div>
        
        <div class="col-sm-6">
        <h4>Details</h4>
        <p>some text</p>
        <hr/>
           
        </div>
        </div>
    </div>
    </div>
    <div class="modal-footer">
    <button class="btn btn-default" data-dismiss="modal">Cloase</button>
        <button class="btn btn-warning" type="submit"><span class="glyphicon glyphicon-shopping-cart"></span>Add to cart</button>
    </div>
    </div>
    </div>
</div>
    </body>
</html>