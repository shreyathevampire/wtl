<html>
<head><title>products</title>


 <link rel="stylesheet" href="/home/user/Desktop/project/home.css" type="text\css">
 <style>
  #images{
     width :auto;
        height: 200px;
  }


 </style>
</head>


<body>

<div class="container">
 <div class="row">
       <H2><div class="text-center"> FIRST YEAR BOOKS </div></H2> 
       <div class="col-md-3">
       <h4>APPLIED CHEMISTRY </h4>
       <img src="chemistry.png" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : ANONYMOUS </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>

        <div class="col-md-3">
       <h4>APPLIED PHYSICS </h4>
       <img src="physics.png" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : ANONYMOUS </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>

        <div class="col-md-3">
       <h4>APPLIED MATHEMATICS </h4>
       <img src="maths.JPG" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : KHUMBHOJKAR </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>
        
    </div>

     <div class="row">
       <H2><div class="text-center"> FIRST YEAR BOOKS </div></H2> 
       <div class="col-md-3">
       <h4>APPLIED CHEMISTRY </h4>
       <img src="chemistry.png" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : ANONYMOUS </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>

        <div class="col-md-3">
       <h4>APPLIED PHYSICS </h4>
       <img src="physics.png" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : ANONYMOUS </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>

        <div class="col-md-3">
       <h4>APPLIED MATHEMATICS </h4>
       <img src="maths.JPG" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : KHUMBHOJKAR </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>
        
    </div>

     <div class="row">
       <H2><div class="text-center"> FIRST YEAR BOOKS </div></H2> 
       <div class="col-md-3">
       <h4>APPLIED CHEMISTRY </h4>
       <img src="chemistry.png" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : ANONYMOUS </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>

        <div class="col-md-3">
       <h4>APPLIED PHYSICS </h4>
       <img src="physics.png" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : ANONYMOUS </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>

        <div class="col-md-3">
       <h4>APPLIED MATHEMATICS </h4>
       <img src="maths.JPG" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : KHUMBHOJKAR </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>
        
    </div>

     <div class="row">
       <H2><div class="text-center"> FIRST YEAR BOOKS </div></H2> 
       <div class="col-md-3">
       <h4>APPLIED CHEMISTRY </h4>
       <img src="chemistry.png" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : ANONYMOUS </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>

        <div class="col-md-3">
       <h4>APPLIED PHYSICS </h4>
       <img src="physics.png" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : ANONYMOUS </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>

        <div class="col-md-3">
       <h4>APPLIED MATHEMATICS </h4>
       <img src="maths.JPG" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : KHUMBHOJKAR </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>
        
    </div>

     <div class="row">
       <H2><div class="text-center"> FIRST YEAR BOOKS </div></H2> 
       <div class="col-md-3">
       <h4>APPLIED CHEMISTRY </h4>
       <img src="chemistry.png" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : ANONYMOUS </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>

        <div class="col-md-3">
       <h4>APPLIED PHYSICS </h4>
       <img src="physics.png" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : ANONYMOUS </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>

        <div class="col-md-3">
       <h4>APPLIED MATHEMATICS </h4>
       <img src="maths.JPG" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : KHUMBHOJKAR </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>
        
    </div>
    </div>


</body>
</html>