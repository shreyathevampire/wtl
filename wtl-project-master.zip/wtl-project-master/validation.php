<?php

$con = mysqli_connect("localhost","root","","registrationform");



if(isset($_POST["submit"])){  
  
    echo ("entered in validation.php inside submit");
if(!empty($_POST['name']) && !empty($_POST['password'])) {  
    echo ("entered in validation.php inside submit inside user and pass");
    $user=$_POST['name'];  
    echo $user;
    $pass=$_POST['password'];
    echo $pass;
  
   /* $con=mysql_connect('localhost','root','') or die(mysql_error());  
    mysql_select_db('registrationform') or die("cannot select DB"); */ 
  
    $result=mysqli_query($con,"SELECT * FROM form WHERE username='".$user."' AND password='".$pass."'");  
    print $result;
   // $numrows=mysqli_num_rows($query);
     $rowcount=mysqli_num_rows($result);
  printf("Result set has %d rows.\n",$rowcount);
   // echo $numrows;
    
    if($rowcount!=0)  
    {  
    while($row=mysqli_fetch_assoc($result))  
    {  
    $dbusername=$row['username'];  
    $dbpassword=$row['password'];  
    }  
  
    if($user == $dbusername && $pass == $dbpassword)  
    {  
    session_start();  
    $_SESSION['sess_user']=$user;  
  
    /* Redirect browser */  
    header("Location: member.php");  
    }  
    } else {  
    echo "Invalid username or password!";  
    }  
  
} else {  
    echo "All fields are required!";  
}  
}  
?>