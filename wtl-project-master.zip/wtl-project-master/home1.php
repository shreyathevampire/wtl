

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/home/user/Desktop/project/home.css" type="text\css">

  <style>
  .navbar-brand,
 {
      line-height: 80px;
      height: 80px;
      padding: 0;
      width: 100px;
  }
.active,
.navbar-nav li {
    line-height: 120px;
  margin-top: 15px;
  align: center;

}
img{
  border-radius: 50%;
}

form{
  align: center;
}
.tech{
  border-radius: 8px;
}
    
    .books{
          border-radius: 0px;
        height : 200px;
        width: 160px;
        position: relative;
      }

  #images{
     width :auto;
        height: 200px;
  }

  #navbar-nav
  {
    height: 120px;
  }

        </style>
</head>

<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
  <!--    <a class="navbar-brand" href="#">
          <img src="book-recycling.png" width=100 height=90 align="left"> </a> -->
    </div>  <!-- navbar header -->
    <div class="collapse navbar-collapse" id="myNavbar">
      <a class="navbar-brand" href="#">
          <img src="book-recycling.png" width=100 height=90 align="left"> </a>
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
        <li> <a href="sign in.html">Make-A-Donation </a></li>
        <li><a href="contact us.html">About Us</a></li>
        <li><a href="#">Contact Us</a></li>
      <!--  <li><form class="form-inline mt-2 mt-md-0">
          <input class="form-control mr-sm-2" placeholder="Search" aria-label="Search" type="text">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button> -->
        </form></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
      <!--  <form class="form-inline mt-2 mt-md-0">
          <input class="form-control mr-sm-2" placeholder="Search" aria-label="Search" type="text" align="center">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form> -->
        <li><a href="register.html"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
        <li><a href="sign in.html"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
    </div>    <!-- collapse navbar -->
  </div>
</nav>

<div class="container">

  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="quote.jpg" alt="Los Angeles" style="width:100%; ">
      </div>

      <div class="item">
        <img src="book.jpg" alt="Chicago" style="width:100%; ">
      </div>

      <div class="item">
        <img src="qutes2.jpg" alt="New york" style="width:100%;">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

<div class="container">
  <div class="jumbotron">
    <h1>GIVE AWAY!! GET HAPPINESS</h1>
    <p>The BeautiFul Thing about Learning is that</p>
      <p> No One can Take it away from YOU!!!</p>
  </div>
  <div class="container">
    <div class="jumbotron">
      <h1>TECHNOLOGIES USED</h1>
    </br>
  </br>
      <div class="row">
              <div class="col-md-4">
                  <img src="bootstrap.png" alt="bootstrap" height="300" width="300" class="tech" >
                <h2>BOOTSTRAP</h2>
                <p> Build responsive, mobile-first projects on the web with the world's most popular front-end component library.

Bootstrap is an open source toolkit for developing with HTML, CSS, and JS. Quickly prototype your ideas or build your entire app with our Sass variables and mixins, responsive grid system, extensive prebuilt components, and powerful plugins built on jQuery.  </p>
                <p><a class="btn btn-default" href="http://getbootstrap.com/" role="button">View details &raquo;</a></p>
              </div>
              <div class="col-md-4">

                    <img src="html5.png" alt="html" height="300" width="300" class="tech">
                <h2>HTML5</h2>
                <p>Hypertext Markup Language revision 5 (HTML5) is markup language for the structure and presentation of World Wide Web contents. HTML5 supports the traditional HTML and XHTML-style syntax and other new features in its markup, New APIs, XHTML and error handling. </p>
                <p><a class="btn btn-default" href="https://www.w3schools.com/html/html5_intro.asp" role="button">View details &raquo;</a></p>
             </div>
              <div class="col-md-4">


                    <img src="javascript.png" alt="javascript" height="300" width="300" class="tech">
                <h2>JAVASCRIPT</h2>
                <p>JavaScript is a programming language that adds interactivity to your website (for example: games, responses when buttons are pressed or data entered in forms, dynamic styling, animation).</p>
                <p><a class="btn btn-default" href="https://www.w3schools.com/js/" role="button">View details &raquo;</a></p>
              </div>
            </div>

    </div>
    
    
    <div class="row">

       <H2><div class="text-center"> FIRST YEAR BOOKS </div></H2> 
       <div class="col-md-3">
       <h4>APPLIED CHEMISTRY </h4>
       <img src="chemistry.png" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : ANONYMOUS </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>

        <div class="col-md-3">
       <h4>APPLIED PHYSICS </h4>
       <img src="physics.png" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : ANONYMOUS </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>

        <div class="col-md-3">
       <h4>APPLIED MATHEMATICS </h4>
       <img src="maths.JPG" alt="APPLIED CHEMISTRY" id="images"/>
        <p> EDITION : 3 </p>
        <p> author : KHUMBHOJKAR </p>
        <p> publication : techmax </p>
        <p><a class="btn btn-default"  role="button" data-toggle="modal" data-target="#details-1"> View details &raquo;</a></p>
        </div>
        
    </div>
            <div>
       
        <p><a class="btn btn-default" href="products.php" role="button" style="display: block; margin: 0 auto; width=300px; background-color: aqua;"> CHECK FOR MORE PRODUCTS &raquo;</a></p>
        </div>
            
      <footer text="center">
       <p>&copy; 2016 Company, Inc.</p>
     </footer>
   </div>
            
            <!-- details modal -->
    <?php 
       include 'details-chemistry.php';
        include 'details-physics.php';
            include 'details-maths.php';
            include 'details-mechanics.php';
            include 'details-evs.php'; 
            ?>
            <!-- end of deatils modal -->
 
    </div>
</body>
</html>
