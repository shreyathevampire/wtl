<!doctype html>

<?php
$servername = "localhost";
$username="root";
$password="";
$dbname="registrationform";
try{
	$conn = mysqli_connect($servername, $username,$password,$dbname);
//	echo("successful in connection");
}catch(MySQLi_Sql_Exception $ex){
	echo("error in connection");
}

   /* $userID= $_POST['userid'];
   // printf ("user id entered\n");
	$name= $_POST['name'];
    $email= $_POST['email'];
	$phone = $_POST['phone'];
	$user = $_POST['username'];
	$pass = $_POST['password'];
*/

  if(isset($_POST['submit'])){

   /* printf("user id = %d \n",$userID);
    printf("name = %s \n",$name);
        printf("emailid = %s \n",$email);
            printf("phone = %d \n",$phone);
                printf("username = %s \n",$user);
                    printf("password = %s \n",$pass);*/
                     $userID= $_POST['userid'];
   // printf ("user id entered\n");
  $name= $_POST['name'];
    $email= $_POST['email'];
  $phone = $_POST['phone'];
  $user = $_POST['username'];
  $pass = $_POST['password'];

    if(("" == trim($name))  || ("" == trim($email)) || ("" == trim($phone))  || ("" == trim($user)) || ("" == trim($pass))  )
    {
      echo "<script type='text/javascript'>alert('all fields are required to be filled')</script>";
      return;
    }



	$register_query = "INSERT INTO form(userid, name, email, phone,username, password) VALUES ('$userID','$name','$email','$phone','$user','$pass')";
	try{
		$register_result = mysqli_query($conn, $register_query);
		if($register_result){
			if(mysqli_affected_rows($conn)>0){
				//echo("registration successful");
        header('location: welcome.php');
  ?>
        <form action="sign in.html" method="post">
        </form>
  <?php

			}else{
				echo("error in registration");
			}
			
		}
	}catch(Exception $ex){
		echo("error".$ex->getMessage());
	}
}


?>

<html>
   <head>
        <meta charset="utf-8">
        <title>login form</title>
        <link rel="stylesheet"  href="style1.css">
   </head>
   <body>
      <div class="title"><h1>REGISTER</h1></div>
      <div class="container">
      <div class="left"></div>
      <div class="right">
      <div class="formbox">
       <form action="" method="post">
           <p>Userid (optional)</p>
           <input type="text" name="userid" placeholder="UserId">
           <p>Name</p>
           <input type="text" name="name" placeholder="Name">
           <p>Mail Id</p>
           <input type="text" name="email" placeholder="mail@gmail.com">
           <p>Mobile No</p>
           <input type="text" name="phone" placeholder="mobile no">
           <p>Username</p>
           <input type="text" name="username" placeholder="username">
           <p>Password</p>
           <input type="Password" name="password" placeholder="******">
           <input type="submit"  name="submit"  value="REGISTER">
           
        </form>
         </div>
      </div>
  </body>
  </html>
